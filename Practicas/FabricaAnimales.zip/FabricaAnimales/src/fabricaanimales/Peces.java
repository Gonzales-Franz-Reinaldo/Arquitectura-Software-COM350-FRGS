/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fabricaanimales;

/**
 *
 * @author Franz Gonzales
 */
public class Peces implements IPeces{
    public String nombre;
    public double longitud;

    public Peces() {
        this.nombre = "Tiburon";
        this.longitud = 5.3;
    }

    @Override
    public void nadar() {
        System.out.println("El pes " + nombre + "empieza a nadar");
    }

    @Override
    public String toString() {
        return "Peces{" + "nombre=" + nombre + ", longitud=" + longitud + '}';
    }
}

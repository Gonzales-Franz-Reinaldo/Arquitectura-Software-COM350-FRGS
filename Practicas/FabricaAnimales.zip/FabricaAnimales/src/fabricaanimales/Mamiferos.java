/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fabricaanimales;

/**
 *
 * @author Franz Gonzales
 */
public class Mamiferos implements IMamiferos{
    public String nombre;
    public String temperatura;
    public int numeroDePatas;
    public String color;

    @Override
    public void getTemperatura() {
        System.out.println("La temperatura es: " + temperatura);
    }

    public Mamiferos() {
        this.nombre = "Caballo";
        this.temperatura = "25°C";
        this.numeroDePatas = 4;
        this.color = "Negro";
    }

    @Override
    public String toString() {
        return "Mamiferos{" + "nombre=" + nombre + ", temperatura=" + temperatura + ", numeroDePatas=" + numeroDePatas + ", color=" + color + '}';
    }
    
}
